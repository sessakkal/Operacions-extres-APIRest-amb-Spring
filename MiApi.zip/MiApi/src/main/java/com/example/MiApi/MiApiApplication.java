package com.example.MiApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiApiApplication.class, args);
	}
}
