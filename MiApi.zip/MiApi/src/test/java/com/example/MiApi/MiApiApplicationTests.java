package com.example.MiApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
